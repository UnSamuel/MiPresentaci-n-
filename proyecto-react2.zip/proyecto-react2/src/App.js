// App.js
import React from 'react';
import Organismo from './Componentes/Organismo/Organismo'; 
import logo192 from './logo192.png'; 

function App() {
  const estiloPagina = {
    backgroundColor: '#aee1e1', 
    padding: '20px', 
  };

  return (
    <div style={estiloPagina}>
      <img src={logo192} alt="Descripción de la imagen" style={{ width: '350px', height: 'auto' }} />
      <h1>La Vida de Samuel </h1> 
      <Organismo />
    </div>
  );
}

export default App;
