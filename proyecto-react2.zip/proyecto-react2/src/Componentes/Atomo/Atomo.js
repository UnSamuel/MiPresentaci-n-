// Atomo.js
import React from 'react';

const estiloAtomo = {
  border: '2px solid #61b6fb', 
  borderRadius: '8px', 
  padding: '16px', 
  backgroundColor: '#f5f5f5', 
  marginBottom: '20px', 
  fontFamily: 'Arial, sans-serif', 
  boxShadow: '0 0 10px rgba(0, 0, 0, 0.1)', 
};

function Atomo() {
  return (
    <div>
      <ul>
        <li>Nombre: Samuel</li>
        <li>Edad: 20 años</li>
        <li>Lugar: Oruro, Bolivia</li>
        <li>Carrera: Estudiante de Ingeniería de Sistemas</li>
      </ul>
    </div>
  );
}

export default Atomo;
