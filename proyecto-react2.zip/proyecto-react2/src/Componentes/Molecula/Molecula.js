// Molecula.js
import React from 'react';

function Molecula() {
  return (
    <div>
      <h2>Pasa Tiempos</h2>
      <li>Pasatiempo Favorito: Jugar Mobile Legends (ML) y nadar </li>
      <li>Breve descripción sobre el Pasatiempo: Mobile Legends es un juego 5 vs 5 y sobre natacion me gusta nadar el estilo pecho    </li>
    </div>
  );
}

export default Molecula;
