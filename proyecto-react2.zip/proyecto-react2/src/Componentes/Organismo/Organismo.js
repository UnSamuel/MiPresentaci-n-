// Organismo.js
import React from 'react';
import Atomo from '../Atomo/Atomo'; 
import Molecula from '../Molecula/Molecula'; 

function Organismo() {
  return (
    <div>
      <h2>Introduccion</h2>
      <Atomo />
      <Molecula />
    </div>
  );
}

export default Organismo;
